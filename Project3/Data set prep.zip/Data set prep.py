import cv2
import numpy as np

cap = cv2.VideoCapture('detectbuoy.avi')
cv2.destroyAllWindows()
i = 0
while (cap.isOpened()):
    ret, frame = cap.read()
    if ret == False:
        break
    cv2.imwrite('frame' + str(i) + '.jpg', frame)
    i += 1
    # for a in range(0,200,4):
    # Select ROI
    fromCenter = False
    r = cv2.selectROI("Frame" + str(i), frame, fromCenter)
    # Crop image
    CroppedImage = frame[int(r[1]):int(r[1] + r[3]), int(r[0]):int(r[0] + r[2])]
    # Save the cropped image
    # cv2.imwrite('Yellow' + str(i) + '.jpg', CroppedImage)
    # cv2.imwrite('Orange' + str(i) + '.jpg', CroppedImage)
    cv2.imwrite('Green' + str(i) + '.jpg', CroppedImage)
    # Display cropped image
    cv2.imshow("Cropped image", CroppedImage)
    cv2.waitKey(0)
cap.release()
# Closes all the frames
cv2.destroyAllWindows()